import gymnasium as gym
import argparse
import yaml
from env import TestEnv
from settings import CONFIG_DIR

def parse_args(args=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", type=str, default=f"{CONFIG_DIR}/test_env.yaml", help='Configuration to build scenes, assets and agents.')
    return parser.parse_args()

def run_env(args):
    with open(args.config, "r") as f:
        config = yaml.safe_load(f)
        env_id = config['task_name']
    env = gym.make(
        env_id,  
        config=args.config,
        obs_mode="rgbd",
        control_mode="pd_joint_pos",
        render_mode="human"
    )
    obs = env.reset()
    while True:
        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        done = terminated | truncated
        env.render()
        # if done:
        #     env.close()
        #     break

if __name__ == "__main__":
    run_env(parse_args())