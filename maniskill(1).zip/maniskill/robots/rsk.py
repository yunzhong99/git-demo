import sapien
import numpy as np
from mani_skill.agents.base_agent import BaseAgent, Keyframe
from mani_skill.agents.controllers import *
from mani_skill.agents.registration import register_agent
from settings import ASSET_DIR

@register_agent()
class RSK(BaseAgent):
    uid="rsk_omnidirectional"
    urdf_path=f"{ASSET_DIR}/rsk_urdf/robot.urdf"
