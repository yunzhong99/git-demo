import sapien
import numpy as np
from mani_skill.agents.base_agent import BaseAgent, Keyframe
from mani_skill.agents.controllers import *
from mani_skill.agents.registration import register_agent
from settings import ASSET_DIR

@register_agent()
class rb_Summit(BaseAgent):
    uid="rb_summit"
    urdf_path=f"{ASSET_DIR}/robotnik_description-jazzy-devel/robots/rbkairos/rbkairos.urdf.xacro"
